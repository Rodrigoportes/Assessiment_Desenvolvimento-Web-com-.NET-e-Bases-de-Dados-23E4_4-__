﻿using System.ComponentModel.DataAnnotations;

namespace EscolaADM.Data.Models
{
    public class Curso
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        public string NomeCurso { get; set; }

        [Required(ErrorMessage = "O campo Descrição é obrigatório.")]
        public string Descricao { get; set; }

        [Required(ErrorMessage = "O campo Código é obrigatório.")]
        [Range(60, 365, ErrorMessage = "As horas semanais devem estar entre 1 e 20.")]
        public int TotalHorasCurso { get; set; }
    }
}
